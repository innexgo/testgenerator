package com.innexgo.testgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestgeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
